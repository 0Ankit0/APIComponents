using System;
using Microsoft.AspNetCore.Identity;

namespace $safeprojectname$.Models;

public class RoleModel : IdentityRole<Guid>
{

}
