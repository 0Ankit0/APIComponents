﻿using Microsoft.AspNetCore.Identity;

namespace $safeprojectname$.Models
{
    public class User : IdentityUser { }

}
