using System;
using Microsoft.AspNetCore.Identity;

namespace $safeprojectname$.Models;

public class UserRoleModel : IdentityRole
{
    public string? UserId { get; set; }
    public string? RoleName { get; set; }


}
